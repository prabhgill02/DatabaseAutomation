CREATE TABLE IF NOT EXISTS books(id int not null AUTO_INCREMENT, name varchar(255), PRIMARY KEY(id));
INSERT INTO books(name) VALUES('Harry Potter');
INSERT INTO books(name) VALUES('New Chapter');
